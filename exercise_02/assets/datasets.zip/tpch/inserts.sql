COPY REGION FROM '/tmp/tpch/data/region.tbl' WITH DELIMITER AS '|';
COPY NATION FROM '/tmp/tpch/data/nation.tbl' WITH DELIMITER AS '|';
COPY PART FROM '/tmp/tpch/data/part.tbl' WITH DELIMITER AS '|';
COPY SUPPLIER FROM '/tmp/tpch/data/supplier.tbl' WITH DELIMITER AS '|';
COPY SUPPLYPART FROM '/tmp/tpch/data/supplypart.tbl' WITH DELIMITER AS '|';
COPY CUSTOMER FROM '/tmp/tpch/data/customer.tbl' WITH DELIMITER AS '|';
COPY ORDERS FROM '/tmp/tpch/data/orders.tbl' WITH DELIMITER AS '|';
COPY ORDERLINE FROM '/tmp/tpch/data/orderline.tbl' WITH DELIMITER AS '|';

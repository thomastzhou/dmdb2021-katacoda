COPY stops FROM '/tmp/zvv/data/stops.tbl' WITH delimiter AS '|';
COPY trips FROM '/tmp/zvv/data/trips.tbl' WITH delimiter AS '|';
COPY stop_times FROM '/tmp/zvv/data/stop_times.tbl' WITH delimiter AS '|';

﻿
COPY employees FROM '/tmp/employee/data/employees.tbl' WITH delimiter AS '|';
COPY departments FROM '/tmp/employee/data/departments.tbl' WITH delimiter AS '|';
COPY dept_manager FROM '/tmp/employee/data/dept_manager.tbl' WITH delimiter AS '|';
COPY dept_emp FROM '/tmp/employee/data/dept_emp.tbl' WITH delimiter AS '|';
COPY titles FROM '/tmp/employee/data/titles.tbl' WITH delimiter AS '|';
COPY salaries FROM '/tmp/employee/data/salaries.tbl' WITH delimiter AS '|';
